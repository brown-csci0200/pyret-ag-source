This directory holds benchmark files.

You can run them directly from the root of the repo with

    make benchmarks

and some summary information will print.

Their main use, however, is with the pyret-pitometer repository, which expects
the `pitometer` directory to be present, runs the benchmarks, and produces
useful visualizations and cross-branch comparisons.
